// src/components/ui/OnboardingTour.tsx
import React, { useState, useEffect, useRef, useCallback } from 'react';
import Button from './Button.js'; 
import Icon from './Icon.js'; 
import { ICON_PATHS } from '../../constants.js';
import { OnboardingTourProps, OnboardingStep } from '../../types.js';

const OnboardingTour: React.FC<OnboardingTourProps> = ({
  tourKey,
  steps,
  isOpen,
  onClose,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const highlightedElementRef = useRef<HTMLElement | null>(null);
  const originalStylesRef = useRef<{ zIndex?: string; position?: string; outline?: string; boxShadow?: string; scrollMargin?: string; }>({});

  const currentStep = steps[currentStepIndex];

  const cleanupHighlight = useCallback(() => {
    if (highlightedElementRef.current && originalStylesRef.current) {
      try {
        Object.assign(highlightedElementRef.current.style, originalStylesRef.current);
      } catch (e) {
        // Element might have been removed from DOM
        console.warn("OnboardingTour: Could not cleanup styles for highlighted element", e);
      }
      highlightedElementRef.current = null;
      originalStylesRef.current = {};
    }
  }, []);


  useEffect(() => {
    if (!isOpen || !currentStep) {
      cleanupHighlight();
      return;
    }

    const highlightElement = () => {
      cleanupHighlight(); // Clean up previous before highlighting new

      const element = document.querySelector(currentStep.elementQuerySelector) as HTMLElement;
      if (element) {
        highlightedElementRef.current = element;
        originalStylesRef.current = {
          zIndex: element.style.zIndex,
          position: element.style.position,
          outline: element.style.outline,
          boxShadow: element.style.boxShadow,
          scrollMargin: element.style.scrollMargin,
        };

        element.style.zIndex = '10001'; // Higher than backdrop
        if (!element.style.position || element.style.position === 'static') {
          element.style.position = 'relative'; 
        }
        element.style.outline = '3px solid #3b82f6'; // Blue-500
        element.style.boxShadow = '0 0 0 6px rgba(59, 130, 246, 0.4)'; // Softer glow
        element.style.scrollMargin = '100px'; // Add margin for scrolling

        element.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
      } else {
        console.warn(`OnboardingTour: Element not found for selector: ${currentStep.elementQuerySelector}`);
      }
    };

    // Delay slightly to allow page layout to settle, especially after route changes
    const timer = setTimeout(highlightElement, 100);

    return () => {
      clearTimeout(timer);
      cleanupHighlight();
    };
  }, [currentStep, isOpen, cleanupHighlight]);

  const handleNext = () => {
    if (currentStepIndex < steps.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
    } else {
      handleCloseTour(true); // Mark as completed
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(currentStepIndex - 1);
    }
  };

  const handleCloseTour = (completed: boolean) => {
    if (completed) {
      localStorage.setItem(tourKey, 'true');
    }
    setCurrentStepIndex(0); 
    cleanupHighlight();
    onClose();
  };

  if (!isOpen || !currentStep) {
    return null;
  }

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-50 dark:bg-opacity-60 z-[10000] flex items-center justify-center p-4"
      aria-modal="true"
      role="dialog"
    >
      <div
        className="bg-white dark:bg-gray-800 p-5 sm:p-6 rounded-xl shadow-2xl w-full max-w-md transform transition-all"
        role="document"
      >
        <div className="flex justify-between items-center mb-3">
          <h3 id="onboarding-title" className="text-lg sm:text-xl font-semibold text-blue-700 dark:text-blue-400 flex items-center">
            <Icon path={ICON_PATHS.LIGHT_BULB} className="w-5 h-5 sm:w-6 sm:h-6 mr-2" />
            {currentStep.title}
          </h3>
          <span className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">
            Step {currentStepIndex + 1} of {steps.length}
          </span>
        </div>

        <p className="text-sm sm:text-base text-gray-700 dark:text-gray-300 mb-4 sm:mb-6 min-h-[40px]">
          {currentStep.content}
        </p>

        <div className="flex flex-col sm:flex-row justify-between items-center gap-2">
          <Button
            onClick={() => handleCloseTour(false)}
            variant="ghost"
            size="sm"
            className="w-full sm:w-auto dark:text-gray-400 dark:hover:bg-gray-700"
          >
            Skip Tour
          </Button>
          <div className="flex gap-2 w-full sm:w-auto">
            <Button
              onClick={handlePrev}
              disabled={currentStepIndex === 0}
              variant="secondary"
              size="sm"
              className="flex-1 sm:flex-none dark:bg-gray-600 dark:hover:bg-gray-500"
            >
              Previous
            </Button>
            <Button onClick={handleNext} variant="primary" size="sm" className="flex-1 sm:flex-none">
              {currentStepIndex === steps.length - 1 ? 'Finish' : 'Next'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OnboardingTour;
