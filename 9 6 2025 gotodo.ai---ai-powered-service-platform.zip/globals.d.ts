
// This file is intentionally left blank or can be deleted.
// Global types are managed in src/globals.d.ts to avoid conflicts.
export {};
